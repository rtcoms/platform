Clingify
========

I wrote a jQuery plugin for sticky / clingy page elements with lots of cool options. 

Requires jQuery 1.7+.

Documentation and demo here: [http://theroux.github.io/clingify/](http://theroux.github.io/clingify/)
