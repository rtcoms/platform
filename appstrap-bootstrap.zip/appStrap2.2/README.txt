Thank you for buying AppStrap HTML Theme by Themelize.me (http://themelize.me).



The "documentation" folder contains a CHANGELOG & README text files for reference.

The theme code is within the "theme" folder.


Enjoy!